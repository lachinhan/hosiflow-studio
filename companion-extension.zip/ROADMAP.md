# HosiFlow Studio — Lộ Trình Phát Triển & Tính Năng Trọng Tâm

> Tài liệu này theo dõi các tính năng và giai đoạn phát triển tiếp theo của **HosiFlow Studio**, tập trung vào nâng cao năng lực sản xuất phim AI đa nền tảng.
> 
> *(Ghi chú: Toàn bộ nền tảng Canvas Studio, Timeline Native FFmpeg, Script Engine, Preset Workflows và Character Vault đã hoàn tất ổn định ở phiên bản v0.1.2).*

---

## 📋 Danh Mục Tính Năng Đang & Sắp Triển Khai

| Mã | Tính năng chi tiết | Mô tả & Giá trị mang lại | Trạng thái |
| :---: | :--- | :--- | :---: |
| **F-11** | **Multi-Tab Status Engine (Companion)** | Nhận diện đồng thời tab Muse.ai và Google Flow Music (`OFF`/`TAB`/`MUSE`/`FLOW`/`ALL`) | ✅ **Hoàn thành (GĐ 1)** |
| **F-11.1** | **Google Flow Music Adapter** | Tự động hóa DOM soạn nhạc, bắt luồng âm thanh và lưu file MP3 từ flowmusic.app | ✅ **Hoàn thành (GĐ 2)** |
| **F-11.2** | **GenerateAudioNode (BGM Node)** | Node tạo nhạc nền trên Canvas: preset thể loại, đồng bộ thời lượng, Audio Player | ✅ **Hoàn thành (GĐ 3)** |
| **F-11.3** | **End-to-End BGM Timeline Mixdown** | Ghép nối tự động Node Nhạc → Timeline Dock → Native FFmpeg Audio Mix (`amix` & fade) | ✅ **Hoàn thành (GĐ 4)** |

---

## 🎼 Chi Tiết Kế Hoạch: Bộ Chuyển Đổi Đa Nền Tảng AI & Tích Hợp Google Flow Music (`flowmusic.app`)

### Bối cảnh & Mục tiêu thực chiến:
- **Thực tế:** Chất lượng sinh nhạc tích hợp sẵn trên Muse.ai hiện tại còn đơn điệu, chất âm chưa đủ độ sâu và thiếu linh hoạt về nhịp điệu cho các video điện ảnh hoặc viral.
- **Giải pháp:** Tích hợp trực tiếp **Google Flow Music** (`https://www.flowmusic.app` — nền tảng AI Music tiên tiến sử dụng mô hình Gemini & MusicFX) làm cỗ máy sản xuất nhạc nền (BGM) chuyên dụng, kết hợp với Muse.ai (hình ảnh, video, nhân vật và kịch bản) thành một **dây chuyền sản xuất phim AI khép kín (End-to-End Pipeline)**.

```mermaid
flowchart LR
    subgraph Browser ["Chrome Extension (Multi-Tab Companion)"]
        Muse["Muse.ai Tab<br/>(Kịch bản, Nhân vật, Video)"]
        Flow["Google Flow Music Tab<br/>(BGM, Giai điệu, Âm thanh)"]
    end

    subgraph Studio ["HosiFlow Studio (Desktop Canvas)"]
        PromptNode["Prompt / Script Node"]
        CharNode["Character Vault Node"]
        VidNodes["Generate Video Nodes"]
        AudioNode["Generate Audio Node (BGM)"]
        Timeline["Timeline Multi-Track Dock"]
    end

    subgraph Engine ["Native Rust & FFmpeg Engine"]
        FFmpeg["FFmpeg 7.1 Native<br/>(Concat + xfade + amix)"]
        FinalMP4["🎬 Final Video MP4"]
    end

    PromptNode --> VidNodes
    CharNode --> VidNodes
    PromptNode --> AudioNode
    VidNodes -->|video-out| Timeline
    AudioNode -->|audio-out| Timeline
    Muse <-->|HTTP Bridge| VidNodes
    Flow <-->|HTTP Bridge| AudioNode
    Timeline --> FFmpeg --> FinalMP4
```

---

### 📍 Giai Đoạn 1: Kiến Trúc Đa Nền Tảng & Đồng Bộ Trạng Thái Đa Tab (Multi-Tab Heartbeat)
> **Mục tiêu:** Companion Extension và Desktop Studio quản lý đồng thời kết nối tới cả 2 tab nền tảng Muse.ai và FlowMusic mà không bị nhầm lẫn luồng dữ liệu.

1. **Quét URL Đa Nền Tảng trong `manifest.json` & `background.js`:**
   - Khai báo quyền `host_permissions` bổ sung: `*://*.flowmusic.app/*` bên cạnh `*://muse.ai/*`.
   - Thiết lập bộ lọc tab tự động định danh `museTabId` và `flowTabId`.
2. **Cơ chế 5 Trạng Thái Trực Quan (Badge & UI Pill):**
   - ⚪ `OFF` (Xám): Desktop Studio chưa khởi động hoặc chưa mở Bridge.
   - 🟡 `TAB` (Vàng hổ phách): Desktop Studio đang chạy, nhưng chưa mở tab Muse.ai hay FlowMusic nào.
   - 🔵 `MUSE` (Xanh ngọc / Cyan): Đã kết nối Muse.ai (sẵn sàng sinh hình ảnh & video).
   - 🟣 `FLOW` (Tím âm nhạc): Đã kết nối FlowMusic (sẵn sàng sinh nhạc BGM).
   - 🟢 `ALL` / `ON` (Xanh lục Emerald sáng): Cả hai nền tảng đã sẵn sàng kết nối, mở khóa toàn bộ năng lực làm phim tự động.
3. **Mở rộng giao thức Heartbeat:**
   - Endpoint `/api/status` và WebSocket/Long-polling gửi payload:
     ```json
     {
       "online": true,
       "providers": {
         "muse": { "connected": true, "tabId": 1234, "url": "https://muse.ai/workspace" },
         "flowmusic": { "connected": true, "tabId": 5678, "url": "https://www.flowmusic.app" }
       }
     }
     ```

---

### 📍 Giai Đoạn 2: Trình Điều Khiển Google Flow Music Adapter (`flowmusic-adapter.js`)
> **Mục tiêu:** Tự động hóa hoàn toàn thao tác soạn nhạc, kích hoạt mô hình sinh âm thanh trên FlowMusic và thu hồi file MP3 về Desktop.

1. **Tạo Content Script chuyên dụng `flowmusic-adapter.js`:**
   - Nhận diện giao diện soạn nhạc của Google Flow Music (Prompt input, Mood / Genre selector, Tempo, Duration).
2. **Tự động điền Prompt & Kích hoạt (DOM Injection):**
   - Nhận task `GENERATE_AUDIO` từ Desktop Bridge.
   - Tự động điền prompt âm nhạc (thể loại, phong cách hòa âm, nhạc cụ) vào ô input của FlowMusic và giả lập nhấn `Enter` / click nút tạo nhạc.
3. **Giám sát Tiến độ & Bắt luồng âm thanh (Audio Interceptor):**
   - Theo dõi phần tử Audio Player trên FlowMusic DOM hoặc intercept network request `audio/mpeg` / `blob:` khi quá trình sinh hoàn tất.
   - Tải file âm thanh về bộ nhớ tab dưới dạng Blob/ArrayBuffer.
4. **Đẩy File Âm Thanh về Desktop Local Storage:**
   - Gửi file qua API POST `http://127.0.0.1:3030/api/upload-media`.
   - Desktop Axum server lưu file vào thư mục `media/audio_xxxx.mp3` và trả về `media_url` nội bộ tốc độ cao.

---

### 📍 Giai Đoạn 3: Node Tạo Âm Thanh / Nhạc Nền (`GenerateAudioNode` - Music Node)
> **Mục tiêu:** Cung cấp Node chuyên dụng trên Canvas React Flow để người dùng cấu hình, nghe thử và quản lý nhạc nền.

1. **Giao diện Node Âm Nhạc (`GenerateAudioNode.tsx`):**
   - Header màu tím sang trọng (Theme Âm Nhạc đặc trưng), có biểu tượng nốt nhạc `Music2` và nút xóa/đổi tên.
   - Ô nhập mô tả giai điệu / vibe nhạc: có sẵn danh sách Gợi Ý Thể Loại (Preset Hub):
     - *Cinematic Movie Score, Lo-Fi Chill Beats, Cyberpunk EDM Synthwave, Epic Orchestral, Suspense Horror Drone, TikTok Trending Pop Beat,...*
2. **Cổng Kết Nối Input & Output:**
   - **Input Handle (`prompt-in`):** Nhận prompt tự động từ `PromptNode` hoặc phân tích tâm trạng kịch bản từ `ScriptGenerator`.
   - **Output Handle (`audio-out`):** Cung cấp đường dẫn file MP3 đã render để nối trực tiếp vào Timeline Dock.
3. **Đồng Bộ Thời Lượng Tự Động (Auto-Duration Match):**
   - Tùy chọn 1 chạm: *"Khớp thời lượng với Timeline"* — Tự động tính tổng giây của tất cả các Video Node đang kích hoạt để yêu cầu FlowMusic sinh độ dài bản nhạc vừa khít video.
4. **Mini Audio Player tích hợp ngay trên Node:**
   - Thanh Play / Pause, hiển thị dải sóng âm (Waveform), thanh tua thời gian và nút tải nhanh file MP3 về máy.

---

### 📍 Giai Đoạn 4: Ghép Nối Dây Chuyền Hoàn Chỉnh: Canvas → Timeline Dock → Native FFmpeg Mixdown
> **Mục tiêu:** Tự động kết nối nhạc nền vào bàn dựng và xử lý hòa âm chuyên nghiệp bằng Native FFmpeg khi xuất phim.

1. **Nhận diện BGM Track trên Timeline Dock:**
   - Kéo dây từ `GenerateAudioNode` (`audio-out`) thả vào Timeline Dock hoặc chọn track nhạc tự động.
   - Timeline hiển thị thanh BGM Track riêng biệt nằm dưới các Video Clips.
2. **Cấu hình Tùy chỉnh Hòa Âm (Audio Mixing Controls):**
   - Thanh trượt âm lượng Video gốc (Original Audio / Voice-over / SFX) (0% - 100%).
   - Thanh trượt âm lượng Nhạc nền (BGM Volume) (0% - 100%).
   - Tùy chọn **Auto Fade-out**: Tự động giảm dần âm lượng nhạc trong 2 - 3 giây cuối của clip kết thúc để phim dừng lại êm dịu, không bị đứt đoạn gắt.
3. **Lệnh Native FFmpeg Phối Âm Chuyên Nghiệp:**
   - Sử dụng bộ lọc đa luồng âm thanh `amix` kết hợp `volume` và `afade`:
     ```bash
     ffmpeg -i final_concat.mp4 -i bgm.mp3 \
     -filter_complex "[0:a]volume=1.0[v_a];[1:a]volume=0.4,afade=t=out:st=28:d=2[bgm_a];[v_a][bgm_a]amix=inputs=2:duration=first:dropout_transition=2[out_a]" \
     -map 0:v -map "[out_a]" -c:v copy -c:a aac -b:a 192k output_master.mp4
     ```
   - Chạy nền 100% ẩn (`CREATE_NO_WINDOW`) không làm giật lag hay hiện cửa sổ đen khó chịu.
4. **Kiểm thử E2E (End-to-End Validation):**
   - Thực hiện test trọn gói từ 1 kịch bản: Muse.ai sinh 3 phân cảnh video + FlowMusic sinh 1 bản nhạc BGM tương ứng → Ghép thành 1 video MP4 hoàn chỉnh có cả hình ảnh và âm nhạc hài hòa.

